# O Django registra User e Group automaticamente.
