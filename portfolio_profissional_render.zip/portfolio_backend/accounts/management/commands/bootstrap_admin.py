import os

from django.contrib.auth import get_user_model
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction


class Command(BaseCommand):
    help = 'Cria o administrador inicial com variáveis de ambiente, sem redefinir contas existentes.'

    def handle(self, *args, **options):
        password = os.environ.get('DJANGO_SUPERUSER_PASSWORD', '')
        if not password:
            self.stdout.write('Criação do administrador ignorada: senha não configurada.')
            return
        username = os.environ.get('DJANGO_SUPERUSER_USERNAME', 'admin').strip()
        email = os.environ.get('DJANGO_SUPERUSER_EMAIL', '').strip()
        if not username:
            raise CommandError('Configure DJANGO_SUPERUSER_USERNAME.')
        User = get_user_model()
        with transaction.atomic():
            if User.objects.filter(username=username).exists():
                self.stdout.write('A conta já existe; credenciais e permissões preservadas.')
                return
            user = User(username=username, email=email)
            try:
                validate_password(password, user)
            except ValidationError:
                raise CommandError('A senha inicial deve ser forte e conter pelo menos 12 caracteres.')
            User.objects.create_superuser(username=username, email=email, password=password)
        self.stdout.write(self.style.SUCCESS('Administrador inicial criado.'))
