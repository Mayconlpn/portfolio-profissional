# Usa django.contrib.auth.User e permissões nativas.
