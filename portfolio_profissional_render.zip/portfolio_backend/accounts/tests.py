from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse
class AdminTests(TestCase):
    def test_usuario_comum_bloqueado(self):
        u=get_user_model().objects.create_user('comum',password='SenhaSegura123!')
        self.client.force_login(u)
        self.assertEqual(self.client.get(reverse('admin:index')).status_code,302)
    def test_superusuario(self):
        u=get_user_model().objects.create_superuser('admin',password='SenhaSegura123!')
        self.client.force_login(u)
        self.assertEqual(self.client.get(reverse('admin:index')).status_code,200)
