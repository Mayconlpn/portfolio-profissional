from django.contrib import admin
from .models import PerfilProfissional,Tecnologia
@admin.register(PerfilProfissional)
class PerfilAdmin(admin.ModelAdmin):
    list_display=('nome','titulo_profissional','cidade','estado','disponivel_contratacao')
    list_filter=('estado','disponivel_contratacao')
    search_fields=('nome','titulo_profissional','cidade')
    def has_add_permission(self,request):
        return super().has_add_permission(request) and not PerfilProfissional.objects.exists()
@admin.register(Tecnologia)
class TecnologiaAdmin(admin.ModelAdmin):
    list_display=('nome','categoria')
    list_filter=('categoria',)
    search_fields=('nome','descricao')
