from io import BytesIO
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from pypdf import PdfWriter
from .models import PerfilProfissional,Tecnologia
from .validators import validar_pdf,validar_imagem
class PerfilTests(TestCase):
    def setUp(self):self.u=get_user_model().objects.create_user('tester',password='SenhaSegura123!')
    def test_perfil_e_unicidade(self):
        PerfilProfissional.objects.create(usuario=self.u,nome='Teste',titulo_profissional='Dev',biografia='Bio',cidade='Guanambi',estado='BA',email_publico='teste@example.com')
        self.assertEqual(self.client.get('/api/perfil/').status_code,200)
        outro=get_user_model().objects.create_user('outro',password='SenhaSegura123!')
        with self.assertRaises(ValidationError):
            PerfilProfissional.objects.create(usuario=outro,nome='Outro',titulo_profissional='Dev',biografia='Bio',cidade='Cidade',estado='BA',email_publico='outro@example.com')
    def test_uf_invalida(self):
        with self.assertRaises(ValidationError):
            PerfilProfissional.objects.create(usuario=self.u,nome='Teste',titulo_profissional='Dev',biografia='Bio',cidade='Cidade',estado='XX',email_publico='teste@example.com')
    def test_tecnologia(self):
        t=Tecnologia.objects.create(nome='Python',categoria='LINGUAGEM')
        self.assertEqual(str(t),'Python')
    def test_pdf(self):
        w=PdfWriter();w.add_blank_page(width=595,height=842);b=BytesIO();w.write(b)
        validar_pdf(SimpleUploadedFile('cv.pdf',b.getvalue()))
        with self.assertRaises(ValidationError):validar_pdf(SimpleUploadedFile('cv.pdf',b'not a pdf'))
    def test_imagem_invalida(self):
        with self.assertRaises(ValidationError):validar_imagem(SimpleUploadedFile('foto.png',b'not an image'))
