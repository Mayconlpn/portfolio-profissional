from django.core.exceptions import ValidationError
from django.core.validators import FileExtensionValidator
from PIL import Image, UnidentifiedImageError
from pypdf import PdfReader


def validar_pdf(arquivo):
    FileExtensionValidator(['pdf'])(arquivo)
    if arquivo.size > 5 * 1024 * 1024:
        raise ValidationError('PDF deve ter no máximo 5 MB.')
    try:
        arquivo.seek(0)
        if arquivo.read(5) != b'%PDF-':
            raise ValidationError('Assinatura PDF inválida.')
        arquivo.seek(0)
        reader=PdfReader(arquivo,strict=True)
        if reader.is_encrypted or len(reader.pages)<1:
            raise ValidationError('PDF criptografado ou vazio.')
    except ValidationError:
        raise
    except Exception as exc:
        raise ValidationError('PDF inválido ou corrompido.') from exc
    finally:
        arquivo.seek(0)


def validar_imagem(arquivo):
    FileExtensionValidator(['jpg','jpeg','png','webp'])(arquivo)
    if arquivo.size > 3 * 1024 * 1024:
        raise ValidationError('Imagem deve ter no máximo 3 MB.')
    try:
        arquivo.seek(0)
        image=Image.open(arquivo)
        image.verify()
        if image.format not in {'JPEG','PNG','WEBP'}:
            raise ValidationError('Formato de imagem inválido.')
    except ValidationError:
        raise
    except (OSError,ValueError,UnidentifiedImageError) as exc:
        raise ValidationError('Imagem inválida.') from exc
    finally:
        arquivo.seek(0)
