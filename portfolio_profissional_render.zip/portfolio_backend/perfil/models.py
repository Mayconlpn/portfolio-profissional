from django.db import models
from django.core.exceptions import ValidationError
from .validators import validar_pdf,validar_imagem

class PerfilProfissional(models.Model):
    usuario=models.OneToOneField('auth.User',on_delete=models.PROTECT,related_name='perfil_profissional')
    nome=models.CharField(max_length=150)
    titulo_profissional=models.CharField(max_length=150)
    biografia=models.TextField()
    cidade=models.CharField(max_length=100)
    estado=models.CharField(max_length=2)
    foto=models.ImageField(upload_to='perfil/',validators=[validar_imagem],blank=True)
    email_publico=models.EmailField()
    disponivel_contratacao=models.BooleanField(default=True)
    curriculo=models.FileField(upload_to='curriculos/',validators=[validar_pdf],blank=True)
    criado_em=models.DateTimeField(auto_now_add=True)
    atualizado_em=models.DateTimeField(auto_now=True)
    class Meta:
        verbose_name='Perfil profissional'
        verbose_name_plural='Perfis profissionais'
    def clean(self):
        super().clean()
        self.estado=(self.estado or '').strip().upper()
        if self.estado not in {'AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'}:
            raise ValidationError({'estado':'UF inválida.'})
        if PerfilProfissional.objects.exclude(pk=self.pk).exists():
            raise ValidationError('Somente um perfil profissional é permitido.')
    def save(self,*args,**kwargs):
        self.full_clean()
        return super().save(*args,**kwargs)
    def __str__(self):return self.nome

class Tecnologia(models.Model):
    class Categoria(models.TextChoices):
        LINGUAGEM='LINGUAGEM','Linguagem'
        FRAMEWORK='FRAMEWORK','Framework'
        BANCO='BANCO','Banco de dados'
        FERRAMENTA='FERRAMENTA','Ferramenta'
        OUTRA='OUTRA','Outra'
    nome=models.CharField(max_length=100,unique=True)
    categoria=models.CharField(max_length=20,choices=Categoria.choices)
    descricao=models.TextField(blank=True)
    class Meta:
        ordering=['nome']
    def save(self,*args,**kwargs):
        self.full_clean()
        return super().save(*args,**kwargs)
    def __str__(self):return self.nome
