(() => {
  'use strict';
  const toggle = document.querySelector('.menu-toggle');
  const mobileNav = document.querySelector('#mobile-nav');
  if (toggle && mobileNav) {
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
      mobileNav.hidden = !open;
    });
    mobileNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      mobileNav.hidden = true;
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Abrir menu');
    }));
  }
  const form = document.querySelector('#proposal-form');
  if (!form) return;
  const feedback = document.querySelector('#form-feedback');
  const submit = form.querySelector('button[type="submit"]');
  form.addEventListener('submit', async event => {
    event.preventDefault();
    feedback.classList.remove('success', 'error');
    if (!form.reportValidity()) return;
    const fields = new FormData(form);
    const payload = Object.fromEntries(fields.entries());
    delete payload.csrfmiddlewaretoken;
    const csrf = fields.get('csrfmiddlewaretoken');
    submit.disabled = true;
    feedback.textContent = 'Enviando sua proposta...';
    try {
      const response = await fetch(form.action, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRFToken': csrf, 'Accept': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify(payload),
      });
      const data = await response.json().catch(() => ({}));
      if (response.ok) {
        form.reset();
        feedback.textContent = 'Proposta enviada com sucesso. Obrigado pelo contato!';
        feedback.classList.add('success');
      } else if (response.status === 429) {
        feedback.textContent = 'Muitas tentativas. Aguarde antes de tentar novamente.';
        feedback.classList.add('error');
      } else if (data.errors) {
        const first = Object.values(data.errors).flat()[0];
        feedback.textContent = first?.message || 'Confira os campos e tente novamente.';
        feedback.classList.add('error');
      } else {
        feedback.textContent = data.detail || 'Não foi possível enviar. Tente novamente.';
        feedback.classList.add('error');
      }
    } catch (_) {
      feedback.textContent = 'Erro de conexão. Verifique sua internet e tente novamente.';
      feedback.classList.add('error');
    } finally {
      submit.disabled = false;
    }
  });
})();
