from django.http import JsonResponse
from django.views.decorators.http import require_GET
from django.shortcuts import get_object_or_404
from perfil.models import PerfilProfissional,Tecnologia
from projetos.models import Projeto
from experiencias.models import ExperienciaProfissional,FormacaoAcademica,Certificacao

def img_url(request,field):
    return request.build_absolute_uri(field.url) if field else None
@require_GET
def perfil(request):
    p=PerfilProfissional.objects.first()
    if p is None:return JsonResponse({'detail':'Perfil não cadastrado.'},status=404)
    return JsonResponse({'nome':p.nome,'titulo_profissional':p.titulo_profissional,'biografia':p.biografia,'cidade':p.cidade,'estado':p.estado,'foto':img_url(request,p.foto),'email_publico':p.email_publico,'disponivel_contratacao':p.disponivel_contratacao})
@require_GET
def tecnologias(request):
    return JsonResponse({'results':list(Tecnologia.objects.values('id','nome','categoria','descricao'))})
def serializar_projeto(request,p):
    return {'titulo':p.titulo,'slug':p.slug,'descricao':p.descricao,'imagem':img_url(request,p.imagem),'tecnologias':[{'nome':t.nome,'categoria':t.categoria} for t in p.tecnologias.all()],'github_url':p.github_url,'demonstracao_url':p.demonstracao_url}
@require_GET
def projetos(request):
    qs=Projeto.objects.filter(publicado=True).prefetch_related('tecnologias')
    return JsonResponse({'results':[serializar_projeto(request,p) for p in qs]})
@require_GET
def projeto_detalhe(request,slug):
    p=get_object_or_404(Projeto.objects.prefetch_related('tecnologias'),slug=slug,publicado=True)
    return JsonResponse(serializar_projeto(request,p))
@require_GET
def experiencias(request):
    return JsonResponse({'results':list(ExperienciaProfissional.objects.values('empresa','cargo','descricao','inicio','termino','emprego_atual'))})
@require_GET
def formacoes(request):
    return JsonResponse({'results':list(FormacaoAcademica.objects.values('instituicao','curso','nivel','inicio','termino','situacao'))})
@require_GET
def certificacoes(request):
    return JsonResponse({'results':list(Certificacao.objects.values('nome','emissor','data_emissao','url_verificacao'))})

from django.views.decorators.csrf import ensure_csrf_cookie
@ensure_csrf_cookie
@require_GET
def csrf(request):
    return JsonResponse({'detail':'CSRF cookie initialized.'})
