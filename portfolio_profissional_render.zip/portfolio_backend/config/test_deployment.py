from io import StringIO
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.management import call_command
from django.core.management.base import CommandError
from django.db import OperationalError
from django.test import TestCase


class HealthTests(TestCase):
    def test_database_available(self):
        response = self.client.get('/health/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {'status': 'ok'})
        self.assertIn('no-store', response['Cache-Control'])

    def test_database_unavailable(self):
        with patch('config.health.connection.cursor', side_effect=OperationalError('private database error')):
            response = self.client.get('/health/')
        self.assertEqual(response.status_code, 503)
        self.assertEqual(response.json(), {'status': 'unavailable'})
        self.assertNotContains(response, 'private database error', status_code=503)


class BootstrapAdminTests(TestCase):
    def run_bootstrap(self, **env):
        with patch.dict('os.environ', env, clear=True):
            call_command('bootstrap_admin', stdout=StringIO())

    def test_no_password_creates_no_account(self):
        self.run_bootstrap()
        self.assertFalse(get_user_model().objects.exists())

    def test_creates_admin_once_and_preserves_password(self):
        self.run_bootstrap(DJANGO_SUPERUSER_PASSWORD='Cobalt!Maple719#River')
        user = get_user_model().objects.get(username='admin')
        self.assertTrue(user.is_superuser)
        self.assertTrue(user.is_staff)
        self.assertTrue(user.check_password('Cobalt!Maple719#River'))
        self.run_bootstrap(DJANGO_SUPERUSER_PASSWORD='Another!Strong861#Value')
        user.refresh_from_db()
        self.assertTrue(user.check_password('Cobalt!Maple719#River'))
        self.assertEqual(get_user_model().objects.count(), 1)

    def test_does_not_promote_existing_regular_user(self):
        user = get_user_model().objects.create_user('admin', password='Original!Juniper193#')
        self.run_bootstrap(DJANGO_SUPERUSER_PASSWORD='Cobalt!Maple719#River')
        user.refresh_from_db()
        self.assertFalse(user.is_superuser)
        self.assertFalse(user.is_staff)
        self.assertTrue(user.check_password('Original!Juniper193#'))

    def test_weak_password_is_rejected(self):
        with self.assertRaises(CommandError):
            self.run_bootstrap(DJANGO_SUPERUSER_PASSWORD='123')
        self.assertFalse(get_user_model().objects.exists())
