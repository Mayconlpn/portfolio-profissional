from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse
from perfil.models import PerfilProfissional, Tecnologia
from projetos.models import Projeto
from experiencias.models import ExperienciaProfissional
from datetime import date


class SitePublicoTests(TestCase):
    def test_home_sem_dados(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Transformando')
        self.assertContains(response, 'proposal-form')

    def test_home_exibe_somente_projetos_publicados(self):
        Projeto.objects.create(titulo='Visivel', descricao='Projeto público', publicado=True)
        Projeto.objects.create(titulo='Oculto', descricao='Projeto privado', publicado=False)
        response = self.client.get(reverse('home'))
        self.assertContains(response, 'Visivel')
        self.assertNotContains(response, 'Oculto')

    def test_home_exibe_dados_do_perfil(self):
        user = get_user_model().objects.create_user(username='portfolio', password='SenhaForte123!')
        perfil = PerfilProfissional.objects.create(
            usuario=user, nome='Pessoa Teste', titulo_profissional='Desenvolvedor',
            biografia='Construindo soluções digitais.', cidade='Salvador', estado='BA',
            email_publico='publico@example.com',
        )
        ExperienciaProfissional.objects.create(
            perfil=perfil, empresa='Empresa Exemplo', cargo='Dev Python',
            descricao='Desenvolvimento de aplicações.', inicio=date(2024, 1, 1), emprego_atual=True,
        )
        response = self.client.get(reverse('home'))
        self.assertContains(response, 'Pessoa Teste')
        self.assertContains(response, 'Empresa Exemplo')
        self.assertContains(response, 'publico@example.com')
