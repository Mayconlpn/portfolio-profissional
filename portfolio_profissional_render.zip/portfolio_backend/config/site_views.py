from django.shortcuts import render
from django.views.decorators.http import require_GET
from django.db.models import Prefetch
from perfil.models import PerfilProfissional, Tecnologia
from projetos.models import Projeto
from experiencias.models import ExperienciaProfissional, FormacaoAcademica, Certificacao


@require_GET
def home(request):
    perfil = PerfilProfissional.objects.first()
    tecnologias = Tecnologia.objects.all().order_by('categoria', 'nome')
    projetos = Projeto.objects.filter(publicado=True).prefetch_related('tecnologias').order_by('-criado_em')
    experiencias = ExperienciaProfissional.objects.none()
    formacoes = FormacaoAcademica.objects.none()
    certificacoes = Certificacao.objects.none()
    if perfil:
        experiencias = ExperienciaProfissional.objects.filter(perfil=perfil).order_by('-inicio')
        formacoes = FormacaoAcademica.objects.filter(perfil=perfil).order_by('-inicio')
        certificacoes = Certificacao.objects.filter(perfil=perfil).order_by('-data_emissao')
    return render(request, 'site/home.html', {
        'perfil': perfil, 'tecnologias': tecnologias, 'projetos': projetos,
        'experiencias': experiencias, 'formacoes': formacoes, 'certificacoes': certificacoes,
    })
