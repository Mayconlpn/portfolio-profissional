from pathlib import Path
import environ

BASE_DIR = Path(__file__).resolve().parent.parent
env = environ.Env(DEBUG=(bool, False), DATABASE_PORT=(int,5432), SECURE_SSL_REDIRECT=(bool,False), SECURE_HSTS_SECONDS=(int,0), TRUST_PROXY_SSL_HEADER=(bool,False), RATE_LIMIT=(int,5), RATE_WINDOW=(int,3600))
environ.Env.read_env(BASE_DIR / '.env')
SECRET_KEY = env('SECRET_KEY')
DEBUG = env('DEBUG')
ALLOWED_HOSTS = env.list('ALLOWED_HOSTS', default=['localhost','127.0.0.1'])
CSRF_TRUSTED_ORIGINS = env.list('CSRF_TRUSTED_ORIGINS', default=[])
RENDER_EXTERNAL_HOSTNAME = env('RENDER_EXTERNAL_HOSTNAME', default='')
if RENDER_EXTERNAL_HOSTNAME:
    if RENDER_EXTERNAL_HOSTNAME not in ALLOWED_HOSTS:
        ALLOWED_HOSTS.append(RENDER_EXTERNAL_HOSTNAME)
    render_origin = f'https://{RENDER_EXTERNAL_HOSTNAME}'
    if render_origin not in CSRF_TRUSTED_ORIGINS:
        CSRF_TRUSTED_ORIGINS.append(render_origin)
INSTALLED_APPS = ['django.contrib.admin','django.contrib.auth','django.contrib.contenttypes','django.contrib.sessions','django.contrib.messages','django.contrib.staticfiles','accounts','perfil','projetos','experiencias','contatos']
MIDDLEWARE = ['django.middleware.security.SecurityMiddleware','whitenoise.middleware.WhiteNoiseMiddleware','django.contrib.sessions.middleware.SessionMiddleware','django.middleware.common.CommonMiddleware','django.middleware.csrf.CsrfViewMiddleware','django.contrib.auth.middleware.AuthenticationMiddleware','django.contrib.messages.middleware.MessageMiddleware','django.middleware.clickjacking.XFrameOptionsMiddleware']
ROOT_URLCONF = 'config.urls'
TEMPLATES = [{'BACKEND':'django.template.backends.django.DjangoTemplates','DIRS':[BASE_DIR/'templates'],'APP_DIRS':True,'OPTIONS':{'context_processors':['django.template.context_processors.debug','django.template.context_processors.request','django.contrib.auth.context_processors.auth','django.contrib.messages.context_processors.messages']}}]
WSGI_APPLICATION = 'config.wsgi.application'
ASGI_APPLICATION = 'config.asgi.application'
if env('DATABASE_URL', default=''):
    DATABASES = {'default': env.db('DATABASE_URL')}
    DATABASES['default'].update(CONN_MAX_AGE=60, CONN_HEALTH_CHECKS=True)
else:
    DATABASES = {'default':{'ENGINE':'django.db.backends.postgresql','NAME':env('DATABASE_NAME'),'USER':env('DATABASE_USER'),'PASSWORD':env('DATABASE_PASSWORD'),'HOST':env('DATABASE_HOST',default='127.0.0.1'),'PORT':env('DATABASE_PORT'),'OPTIONS':{'sslmode':env('DB_SSLMODE',default='prefer')},'CONN_MAX_AGE':60,'CONN_HEALTH_CHECKS':True}}
AUTH_PASSWORD_VALIDATORS = [{'NAME':'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},{'NAME':'django.contrib.auth.password_validation.MinimumLengthValidator','OPTIONS':{'min_length':12}},{'NAME':'django.contrib.auth.password_validation.CommonPasswordValidator'},{'NAME':'django.contrib.auth.password_validation.NumericPasswordValidator'}]
LANGUAGE_CODE='pt-br'
TIME_ZONE='America/Bahia'
USE_I18N=True
USE_TZ=True
STATIC_URL='static/'
STATICFILES_DIRS=[BASE_DIR/'static']
STATIC_ROOT=BASE_DIR/'staticfiles'
STORAGES={'staticfiles':{'BACKEND':'whitenoise.storage.CompressedManifestStaticFilesStorage'},'default':{'BACKEND':'django.core.files.storage.FileSystemStorage'}}
MEDIA_URL='media/'
MEDIA_ROOT=BASE_DIR/'media'
DEFAULT_AUTO_FIELD='django.db.models.BigAutoField'
SECURE_CONTENT_TYPE_NOSNIFF=True
X_FRAME_OPTIONS='DENY'
SESSION_COOKIE_HTTPONLY=True
CSRF_COOKIE_HTTPONLY=False  # Bootstrap forms need the CSRF token cookie
SECURE_SSL_REDIRECT=env('SECURE_SSL_REDIRECT')
SESSION_COOKIE_SECURE=not DEBUG
CSRF_COOKIE_SECURE=not DEBUG
SECURE_HSTS_SECONDS=env('SECURE_HSTS_SECONDS') if not DEBUG else 0
SECURE_HSTS_INCLUDE_SUBDOMAINS=env.bool('SECURE_HSTS_INCLUDE_SUBDOMAINS', default=False)
SECURE_HSTS_PRELOAD=env.bool('SECURE_HSTS_PRELOAD', default=False)
SECURE_PROXY_SSL_HEADER=('HTTP_X_FORWARDED_PROTO','https') if env('TRUST_PROXY_SSL_HEADER') else None
RATE_LIMIT=env('RATE_LIMIT')
RATE_WINDOW=env('RATE_WINDOW')
# Configure shared Redis cache in multi-worker production; local memory is per-process.
CACHES={'default':{'BACKEND':'django.core.cache.backends.locmem.LocMemCache'}}
