from django.urls import path
from . import views
from contatos.views import enviar_proposta
urlpatterns=[path('csrf/',views.csrf,name='api-csrf'),path('perfil/',views.perfil,name='api-perfil'),path('tecnologias/',views.tecnologias,name='api-tecnologias'),path('projetos/',views.projetos,name='api-projetos'),path('projetos/<slug:slug>/',views.projeto_detalhe,name='api-projeto'),path('experiencias/',views.experiencias,name='api-experiencias'),path('formacoes/',views.formacoes,name='api-formacoes'),path('certificacoes/',views.certificacoes,name='api-certificacoes'),path('propostas/',enviar_proposta,name='api-propostas')]
