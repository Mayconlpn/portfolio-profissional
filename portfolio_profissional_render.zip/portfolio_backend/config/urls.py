from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from .site_views import home
from .health import health
urlpatterns=[path('',home,name='home'),path('health/',health,name='health'),path('admin/',admin.site.urls),path('api/',include('config.api_urls'))]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
admin.site.site_header='Administração do Portfólio'
admin.site.site_title='Portfólio Profissional'
