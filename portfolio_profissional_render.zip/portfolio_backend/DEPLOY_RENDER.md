# Publicar o portfólio no Render

## Configuração preparada

- Workspace escolhido anteriormente: **Portifólio**.
- Repositório: https://github.com/Mayconlpn/portfolio-profissional
- Serviço web `portfolio-maycon`, Python 3.12, plano gratuito.
- PostgreSQL `portfolio-maycon-db`, plano gratuito, na mesma região do serviço: Virginia.
- `render.yaml` gera a chave do Django e vincula a conexão interna do banco sem gravar segredos no código.
- `build.sh` instala dependências, coleta CSS/JavaScript e verifica a configuração de produção.
- `start.sh` aplica as migrações versionadas e inicia o Gunicorn na porta fornecida pelo Render.
- `/health/` verifica se o servidor consegue consultar o banco.

O repositório inclui a configuração de implantação. O serviço OpenJarvis no outro workspace permanece fora desta configuração. Quando o código é distribuído como ZIP no GitHub, o Blueprint da raiz extrai o pacote antes de executar `build.sh`.

## Publicação

1. Extraia o ZIP. Envie **o conteúdo de `portfolio_backend`** para a raiz do repositório, de modo que `manage.py`, `requirements.txt` e `render.yaml` apareçam diretamente na página principal do GitHub. Não envie apenas o ZIP, nem pastas de ambiente virtual.
2. Confirme que os arquivos estão na branch `main`. O Render precisa lê-los no GitHub antes de criar a implantação.
3. Abra https://dashboard.render.com/blueprint/new?repo=https://github.com/Mayconlpn/portfolio-profissional e selecione o workspace **Portifólio**.
4. Revise os dois recursos. Ambos devem mostrar o plano **Free**. O Blueprint não solicita recursos pagos.
5. Defina `DJANGO_SUPERUSER_PASSWORD` com uma senha exclusiva de pelo menos 12 caracteres. Ela deve ser preenchida no painel do Render, nunca no repositório. O usuário inicial é `admin`.
6. Aplique o Blueprint e acompanhe o deploy até o status **Live**. Uma confirmação de criação do serviço ainda não significa que o site está funcionando.
7. Abra a URL pública fornecida pelo Render, teste `/health/`, confira os estilos e acesse `/admin/` com o administrador inicial. Cadastre seu perfil e seus projetos no painel.
8. Após confirmar o acesso, remova `DJANGO_SUPERUSER_PASSWORD` das variáveis do serviço. A conta permanece no banco; a inicialização nunca redefine a senha ou promove uma conta existente.

Caso publique por comandos Git, utilize `git add .`, `git commit` e `git push origin main` depois de revisar os arquivos. Não há credenciais de GitHub incluídas neste pacote.

Se o Render CLI estiver instalado, execute `render blueprints validate render.yaml` antes de aplicar o Blueprint. O ambiente de preparação validou o arquivo usando o JSON Schema oficial; não executou a validação autenticada do Render CLI.

## Limites do plano gratuito

O PostgreSQL gratuito do Render **expira 30 dias após a criação**. Ele não é uma solução permanente para receber e guardar propostas. Antes do vencimento, exporte os dados e defina um banco de longo prazo. Referência: https://render.com/docs/free#free-postgres

O serviço web gratuito pode entrar em repouso após 15 minutos sem tráfego. A primeira visita pode demorar enquanto ele volta a funcionar.

Arquivos enviados ao disco local, como fotos, imagens de projetos e currículos, não persistem após reinícios, novos deploys ou repouso. Esta implantação não configura armazenamento externo de mídia e não publica a pasta de currículos privados. Configure um serviço de armazenamento com permissões apropriadas antes de usar uploads em produção. Referência: https://render.com/docs/free#local-files-lost-on-redeploy

O Gunicorn inicia com um processo para manter o limitador atual de propostas no mesmo cache local. Antes de aumentar a quantidade de processos ou instâncias, configure um cache compartilhado. O plano gratuito não oferece shell nem pre-deploy commands; por isso as migrações são executadas na inicialização, antes de abrir a porta HTTP.

## Verificação realizada

- 25 testes automatizados aprovados com banco SQLite.
- Migrações iniciais geradas e incluídas; nenhuma migração pendente.
- Coleta de CSS, JavaScript e arquivos do Admin concluída.
- `check --deploy --fail-level WARNING` aprovado com configuração de produção.
- `render.yaml` aprovado pelo JSON Schema oficial obtido de https://render.com/schema/render.yaml.json.
- Scripts de inicialização e build verificados quanto à sintaxe Bash.

Os testes locais não substituem a verificação do PostgreSQL e do domínio público depois do deploy.
