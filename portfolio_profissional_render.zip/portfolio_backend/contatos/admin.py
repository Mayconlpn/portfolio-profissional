from django.contrib import admin
from .models import Proposta
@admin.register(Proposta)
class PropostaAdmin(admin.ModelAdmin):
    list_display=('assunto','empresa','tipo','modalidade','status','visualizada','recebida_em')
    list_filter=('tipo','modalidade','status','visualizada','recebida_em')
    search_fields=('recrutador','empresa','email','assunto')
    readonly_fields=('recrutador','empresa','email','assunto','tipo','modalidade','mensagem','recebida_em')
    def has_add_permission(self,request):return False
    def has_change_permission(self,request,obj=None):
        return request.user.is_active and request.user.is_superuser or (request.user.has_perm('contatos.gerenciar_propostas') and request.user.has_perm('contatos.change_proposta'))
    def has_delete_permission(self,request,obj=None):
        return request.user.is_active and request.user.is_superuser or (request.user.has_perm('contatos.gerenciar_propostas') and request.user.has_perm('contatos.delete_proposta'))
    def has_view_permission(self,request,obj=None):
        return request.user.is_active and request.user.is_superuser or request.user.has_perm('contatos.view_proposta')
    def get_readonly_fields(self,request,obj=None):
        base=super().get_readonly_fields(request,obj)
        if not self.has_change_permission(request,obj):return (*base,'status','visualizada')
        return base
