import json
import hashlib
from django.conf import settings
from django.core.cache import cache
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_protect
from django.db import transaction
from .forms import PropostaForm

@require_POST
@csrf_protect
def enviar_proposta(request):
    if len(request.body)>16_384:
        return JsonResponse({'detail':'Requisição muito grande.'},status=413)
    if request.content_type != 'application/json':
        return JsonResponse({'detail':'Use application/json.'},status=415)
    try:
        data=json.loads(request.body)
        if not isinstance(data,dict):raise ValueError('Objeto esperado')
    except (ValueError,UnicodeDecodeError):
        return JsonResponse({'detail':'JSON inválido.'},status=400)
    # Campo invisível para formulários futuros; bots que o preenchem são descartados.
    if data.get('website'):
        return JsonResponse({'detail':'Proposta recebida.'},status=202)
    # Não confiar em X-Forwarded-For enviado por clientes; REMOTE_ADDR deve ser o IP
    # normalizado pelo proxy de confiança quando implantado.
    client_ip=request.META.get('REMOTE_ADDR','unknown')
    fingerprint=hashlib.sha256((settings.SECRET_KEY+client_ip).encode()).hexdigest()
    key=f'proposal-rate:{fingerprint}'
    if not cache.add(key,1,timeout=settings.RATE_WINDOW):
        try:
            count=cache.incr(key)
        except ValueError:
            cache.set(key,1,timeout=settings.RATE_WINDOW)
            count=1
        if count>settings.RATE_LIMIT:
            response=JsonResponse({'detail':'Muitas tentativas. Tente mais tarde.'},status=429)
            response['Retry-After']=str(settings.RATE_WINDOW)
            return response
    form=PropostaForm(data)
    if not form.is_valid():
        return JsonResponse({'errors':form.errors.get_json_data()},status=400)
    with transaction.atomic():
        form.save()
    return JsonResponse({'detail':'Proposta recebida.'},status=201)
