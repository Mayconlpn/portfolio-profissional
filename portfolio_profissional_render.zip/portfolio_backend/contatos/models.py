from django.db import models

class Proposta(models.Model):
    class Tipo(models.TextChoices):
        EMPREGO='EMPREGO','Emprego'
        ESTAGIO='ESTAGIO','Estágio'
        FREELANCER='FREELANCER','Freelancer'
    class Modalidade(models.TextChoices):
        REMOTO='REMOTO','Remoto'
        PRESENCIAL='PRESENCIAL','Presencial'
        HIBRIDO='HIBRIDO','Híbrido'
    class Status(models.TextChoices):
        NOVA='NOVA','Nova'
        ANALISE='ANALISE','Em análise'
        ACEITA='ACEITA','Aceita'
        RECUSADA='RECUSADA','Recusada'
    recrutador=models.CharField(max_length=120)
    empresa=models.CharField(max_length=160)
    email=models.EmailField()
    assunto=models.CharField(max_length=180)
    tipo=models.CharField(max_length=20,choices=Tipo.choices)
    modalidade=models.CharField(max_length=20,choices=Modalidade.choices)
    mensagem=models.TextField(max_length=5000)
    status=models.CharField(max_length=20,choices=Status.choices,default=Status.NOVA)
    visualizada=models.BooleanField(default=False)
    recebida_em=models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering=['-recebida_em']
        permissions=[('gerenciar_propostas','Pode gerenciar status de propostas')]
    def __str__(self):return f'{self.assunto} — {self.empresa}'
