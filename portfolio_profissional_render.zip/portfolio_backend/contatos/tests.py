import json
from django.test import TestCase,override_settings,Client
from django.contrib.auth import get_user_model
from .models import Proposta
class PropostasTests(TestCase):
    def payload(self):return {'recrutador':'Maria','empresa':'Empresa','email':'maria@example.com','assunto':'Vaga','tipo':'EMPREGO','modalidade':'REMOTO','mensagem':'Gostaríamos de conversar sobre uma vaga de trabalho.'}
    def test_envio_e_privacidade(self):
        r=self.client.post('/api/propostas/',data=json.dumps(self.payload()),content_type='application/json')
        self.assertEqual(r.status_code,201)
        self.assertEqual(Proposta.objects.count(),1)
        self.assertEqual(self.client.get('/api/propostas/').status_code,405)
        self.assertEqual(self.client.get('/admin/contatos/proposta/').status_code,302)
    def test_dados_invalidos(self):
        p=self.payload();p['email']='invalido';p['mensagem']='curta'
        self.assertEqual(self.client.post('/api/propostas/',data=json.dumps(p),content_type='application/json').status_code,400)
    @override_settings(RATE_LIMIT=1)
    def test_limite(self):
        self.client.post('/api/propostas/',data=json.dumps(self.payload()),content_type='application/json')
        self.assertEqual(self.client.post('/api/propostas/',data=json.dumps(self.payload()),content_type='application/json').status_code,429)
    def test_csrf(self):
        c=Client(enforce_csrf_checks=True)
        self.assertEqual(c.post('/api/propostas/',data=json.dumps(self.payload()),content_type='application/json').status_code,403)
    def test_admin_superuser(self):
        u=get_user_model().objects.create_superuser('root',password='SenhaSegura123!')
        self.client.force_login(u)
        self.assertEqual(self.client.get('/admin/contatos/proposta/').status_code,200)
