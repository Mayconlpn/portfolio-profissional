from django import forms
from .models import Proposta
class PropostaForm(forms.ModelForm):
    class Meta:
        model=Proposta
        fields=['recrutador','empresa','email','assunto','tipo','modalidade','mensagem']
    def clean_mensagem(self):
        value=self.cleaned_data['mensagem'].strip()
        if len(value)<20:
            raise forms.ValidationError('A mensagem precisa ter pelo menos 20 caracteres.')
        return value
