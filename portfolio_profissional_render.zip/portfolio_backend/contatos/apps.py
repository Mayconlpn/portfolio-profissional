from django.apps import AppConfig
class ContatosConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'
    name='contatos'
    verbose_name='Propostas'
