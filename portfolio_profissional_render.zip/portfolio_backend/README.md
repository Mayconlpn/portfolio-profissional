# Portfólio profissional — back-end Django

Projeto integrado das três etapas: perfil, tecnologias, projetos, experiências, formação, certificações e recebimento privado de propostas. Inclui página pública em Django e painel Django Admin.

## Requisitos

Python 3.12+ (compatível com Django 5.2), PostgreSQL 14+ e dependências de `requirements.txt`.

## Instalação

```bash
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
cp .env.example .env  # Windows: copy .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(64))"
```

Preencha `SECRET_KEY`, senha e host do banco no `.env`.

No `psql`, como administrador:

```sql
CREATE USER portfolio_user WITH PASSWORD 'SENHA_FORTE';
CREATE DATABASE portfolio_db OWNER portfolio_user ENCODING 'UTF8';
```

Execute:

```bash
python manage.py migrate
python manage.py createsuperuser
python manage.py check
python manage.py test
python manage.py runserver
```

Admin: `http://127.0.0.1:8000/admin/`. Cadastre um perfil, tecnologias, projetos, experiências, formações e certificações. Somente projetos com `publicado=True` aparecem na API.

**Migrações:** as migrações iniciais estão incluídas e devem ser versionadas. Execute `makemigrations` apenas quando alterar os modelos.

## API pública (JSON)

| Método | Rota | Finalidade |
|---|---|---|
| GET | `/api/csrf/` | Inicializa cookie CSRF para POST no mesmo domínio |
| GET | `/api/perfil/` | Perfil sem currículo privado |
| GET | `/api/tecnologias/` | Habilidades |
| GET | `/api/projetos/` | Somente projetos publicados |
| GET | `/api/projetos/<slug>/` | Detalhes publicados |
| GET | `/api/experiencias/` | Experiências |
| GET | `/api/formacoes/` | Formação acadêmica |
| GET | `/api/certificacoes/` | Cursos e certificações |
| POST | `/api/propostas/` | Recebe proposta; não oferece GET |

A API usa views JSON nativas do Django, sem Django REST Framework. Não há CORS habilitado: integre Bootstrap no mesmo domínio por padrão.

### Enviar proposta com CSRF

A rota exige `Content-Type: application/json` e token CSRF. O front-end Django/Bootstrap deverá obter o token do cookie `csrftoken` de `GET /api/csrf/` e enviá-lo no cabeçalho `X-CSRFToken`. Para testar via curl, obtenha cookie e token de uma sessão válida; não desabilite CSRF. Exemplo do corpo:

```json
{
  "recrutador":"Maria",
  "empresa":"Empresa Exemplo",
  "email":"maria@example.com",
  "assunto":"Oportunidade Python",
  "tipo":"EMPREGO",
  "modalidade":"REMOTO",
  "mensagem":"Gostaríamos de conversar sobre uma vaga de desenvolvedor Python."
}
```

Resposta 201: `{"detail":"Proposta recebida."}`. Dados inválidos retornam 400, excesso de tentativas 429, ausência de CSRF 403. O teste automatizado usa o cliente de testes Django. Visitantes não conseguem consultar propostas pela API. Status e visualização são gerenciados no Admin com permissões apropriadas.

## Segurança e produção

- Defina `DEBUG=False`, `ALLOWED_HOSTS=seudominio.com`, `CSRF_TRUSTED_ORIGINS=https://seudominio.com`, `SECURE_SSL_REDIRECT=True` e `SECURE_HSTS_SECONDS=31536000` **após** confirmar HTTPS funcional.
- Use um proxy reverso TLS confiável; só defina `TRUST_PROXY_SSL_HEADER=True` se o proxy limpar e definir corretamente `X-Forwarded-Proto`.
- Execute `python manage.py collectstatic --noinput`, `python manage.py check --deploy`, `python manage.py migrate` e `gunicorn config.wsgi:application` atrás de um proxy HTTPS.
- **Obrigatório antes de escalar:** substituir o cache local por Redis compartilhado, com incremento atômico para rate limiting. O limitador atual é apenas uma proteção básica por processo, não garantia distribuída.
- Sirva uploads em infraestrutura separada, com controles de tamanho, antivírus e acesso privado para currículos. A URL pública `/media/` não deve expor currículos. Não publique `MEDIA_ROOT` integralmente. Imagens públicas podem ser disponibilizadas por uma política de armazenamento separada.
- Não exponha `.env`; faça backup do banco, configure logs, monitoramento e política de retenção de dados pessoais (LGPD).
- O perfil único é validado na aplicação, não protegido contra concorrência no banco. Adicione restrição transacional/banco antes de permitir gravações paralelas.
- Limite de requisição é aplicado por `REMOTE_ADDR`; configure o proxy para preservar o IP real de maneira confiável, sem aceitar cabeçalhos de origem do cliente.
- Uploads são validados em nível básico; inspeção antivírus e isolamento dos arquivos são necessários antes da publicação.

## Bootstrap futuro

Crie templates Django e views que consumam diretamente o ORM, ou use `fetch` na API no mesmo domínio. Em formulários POST use `{% csrf_token %}` (templates Django) ou `X-CSRFToken` (requisições JSON). Não exponha status privados ou propostas em endpoints públicos.

## Verificação

Foram executados 25 testes automatizados com SQLite, a coleta dos arquivos estáticos, a verificação de migrações pendentes e `check --deploy --fail-level WARNING` com configuração de produção. O Blueprint foi validado contra o JSON Schema oficial do Render. A conexão com PostgreSQL e o funcionamento no domínio público ainda dependem da implantação remota. Consulte `DEPLOY_RENDER.md` para publicar.

## Front-end público (integrado)

A página inicial em `/` utiliza templates Django e CSS/JavaScript próprios. Não depende de Bootstrap nem de build com Node.js. O conteúdo vem dos modelos existentes e é gerenciado pelo Django Admin em `/admin/`.

- `config/site_views.py`: consulta o perfil e os dados relacionados para a página inicial.
- `templates/site/home.html`: layout responsivo com hero, sobre, tecnologias, projetos publicados, trajetória, certificações e contato.
- `static/site/style.css`: estilos responsivos, incluindo versão mobile.
- `static/site/main.js`: navegação móvel e envio de propostas em JSON para `/api/propostas/`, com token CSRF do formulário.
- `config/test_site.py`: testes de renderização e ocultação de projetos não publicados.

### Personalização

Crie o superusuário e cadastre o perfil, tecnologias, projetos e experiências pelo Admin. Não há dados profissionais fictícios gravados no banco. Projetos em rascunho não são exibidos. A foto e o currículo são usados apenas quando cadastrados.

### Testes e implantação

Execute `python manage.py test` e `python manage.py check --deploy` após instalar as dependências e configurar PostgreSQL. Para publicar os arquivos estáticos execute `python manage.py collectstatic --noinput`. Configure servidor HTTPS, `ALLOWED_HOSTS`, variáveis de ambiente e um serviço de mídia com proteção adequada para currículos. Em produção, a limitação de propostas precisa de um cache compartilhado (Redis) entre os workers; o cache local incluído é adequado apenas para desenvolvimento e testes. Evite expor currículos privados em `/media/` em produção.
