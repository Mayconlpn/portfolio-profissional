from django.contrib import admin
from .models import Projeto
@admin.register(Projeto)
class ProjetoAdmin(admin.ModelAdmin):
    list_display=('titulo','publicado','atualizado_em')
    list_filter=('publicado','tecnologias')
    search_fields=('titulo','descricao','slug')
    prepopulated_fields={'slug':('titulo',)}
    filter_horizontal=('tecnologias',)
    actions=['publicar','ocultar']
    @admin.action(description='Publicar selecionados',permissions=['change'])
    def publicar(self,request,queryset):queryset.update(publicado=True)
    @admin.action(description='Ocultar selecionados',permissions=['change'])
    def ocultar(self,request,queryset):queryset.update(publicado=False)
