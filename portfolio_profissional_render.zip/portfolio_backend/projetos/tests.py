from django.test import TestCase
from django.core.exceptions import ValidationError
from .models import Projeto
from perfil.models import Tecnologia
class ProjetosTests(TestCase):
    def test_publicacao_e_relacionamento(self):
        p=Projeto.objects.create(titulo='Meu Projeto',descricao='Descrição')
        self.assertEqual(p.slug,'meu-projeto')
        t=Tecnologia.objects.create(nome='Python',categoria='LINGUAGEM');p.tecnologias.add(t)
        self.assertEqual(self.client.get('/api/projetos/').json()['results'],[])
        p.publicado=True;p.save()
        data=self.client.get('/api/projetos/').json()['results']
        self.assertEqual(data[0]['tecnologias'][0]['nome'],'Python')
        self.assertEqual(self.client.get('/api/projetos/meu-projeto/').status_code,200)
    def test_slug_duplicado(self):
        Projeto.objects.create(titulo='Duplicado',descricao='Um')
        with self.assertRaises(ValidationError):Projeto.objects.create(titulo='Duplicado',descricao='Dois')
