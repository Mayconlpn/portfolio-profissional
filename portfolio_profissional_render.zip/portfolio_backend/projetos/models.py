from django.db import models
from django.core.exceptions import ValidationError
from django.utils.text import slugify
from perfil.models import Tecnologia
from perfil.validators import validar_imagem

class Projeto(models.Model):
    titulo=models.CharField(max_length=200)
    slug=models.SlugField(max_length=220,unique=True,blank=True)
    descricao=models.TextField()
    imagem=models.ImageField(upload_to='projetos/',validators=[validar_imagem],blank=True)
    tecnologias=models.ManyToManyField(Tecnologia,related_name='projetos',blank=True)
    github_url=models.URLField(blank=True)
    demonstracao_url=models.URLField(blank=True)
    publicado=models.BooleanField(default=False)
    criado_em=models.DateTimeField(auto_now_add=True)
    atualizado_em=models.DateTimeField(auto_now=True)
    class Meta:
        ordering=['-criado_em']
    def clean(self):
        super().clean()
        if not self.slug:
            self.slug=slugify(self.titulo)
        if not self.slug:
            raise ValidationError({'slug':'Informe um slug válido.'})
    def save(self,*args,**kwargs):
        self.full_clean()
        return super().save(*args,**kwargs)
    def __str__(self):return self.titulo
