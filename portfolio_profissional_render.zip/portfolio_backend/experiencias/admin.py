from django.contrib import admin
from .models import ExperienciaProfissional,FormacaoAcademica,Certificacao
@admin.register(ExperienciaProfissional)
class ExperienciaAdmin(admin.ModelAdmin):
    list_display=('cargo','empresa','inicio','termino','emprego_atual')
    list_filter=('emprego_atual',)
    search_fields=('cargo','empresa','descricao')
@admin.register(FormacaoAcademica)
class FormacaoAdmin(admin.ModelAdmin):
    list_display=('curso','instituicao','nivel','situacao')
    list_filter=('situacao',)
    search_fields=('curso','instituicao')
@admin.register(Certificacao)
class CertificacaoAdmin(admin.ModelAdmin):
    list_display=('nome','emissor','data_emissao')
    search_fields=('nome','emissor')
