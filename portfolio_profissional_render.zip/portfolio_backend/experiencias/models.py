from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone

class ExperienciaProfissional(models.Model):
    perfil=models.ForeignKey('perfil.PerfilProfissional',on_delete=models.CASCADE,related_name='experiencias')
    empresa=models.CharField(max_length=160)
    cargo=models.CharField(max_length=160)
    descricao=models.TextField()
    inicio=models.DateField()
    termino=models.DateField(blank=True,null=True)
    emprego_atual=models.BooleanField(default=False)
    class Meta:
        ordering=['-inicio']
        verbose_name='Experiência profissional'
        verbose_name_plural='Experiências profissionais'
    def clean(self):
        super().clean()
        if self.termino and self.termino < self.inicio:
            raise ValidationError({'termino':'Término anterior ao início.'})
        if self.emprego_atual and self.termino:
            raise ValidationError({'termino':'Emprego atual não pode ter término.'})
    def save(self,*args,**kwargs):
        self.full_clean()
        return super().save(*args,**kwargs)
    def __str__(self):return f'{self.cargo} — {self.empresa}'

class FormacaoAcademica(models.Model):
    class Situacao(models.TextChoices):
        CURSANDO='CURSANDO','Cursando'
        CONCLUIDO='CONCLUIDO','Concluído'
        TRANCADO='TRANCADO','Trancado'
    perfil=models.ForeignKey('perfil.PerfilProfissional',on_delete=models.CASCADE,related_name='formacoes')
    instituicao=models.CharField(max_length=160)
    curso=models.CharField(max_length=160)
    nivel=models.CharField(max_length=100)
    inicio=models.DateField()
    termino=models.DateField(blank=True,null=True)
    situacao=models.CharField(max_length=20,choices=Situacao.choices)
    class Meta:
        ordering=['-inicio']
        verbose_name='Formação acadêmica'
        verbose_name_plural='Formações acadêmicas'
    def clean(self):
        super().clean()
        if self.termino and self.termino < self.inicio:
            raise ValidationError({'termino':'Término anterior ao início.'})
    def save(self,*args,**kwargs):
        self.full_clean()
        return super().save(*args,**kwargs)
    def __str__(self):return f'{self.curso} — {self.instituicao}'

class Certificacao(models.Model):
    perfil=models.ForeignKey('perfil.PerfilProfissional',on_delete=models.CASCADE,related_name='certificacoes')
    nome=models.CharField(max_length=160)
    emissor=models.CharField(max_length=160)
    data_emissao=models.DateField()
    url_verificacao=models.URLField(blank=True)
    class Meta:
        ordering=['-data_emissao']
        verbose_name='Curso ou certificação'
        verbose_name_plural='Cursos e certificações'
    def __str__(self):return self.nome
