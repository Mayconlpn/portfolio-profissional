from datetime import date
from django.test import TestCase
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from perfil.models import PerfilProfissional
from .models import ExperienciaProfissional,FormacaoAcademica,Certificacao
class ExperienciasTests(TestCase):
    def setUp(self):
        u=get_user_model().objects.create_user('teste',password='SenhaSegura123!')
        self.perfil=PerfilProfissional.objects.create(usuario=u,nome='Teste',titulo_profissional='Dev',biografia='Bio',cidade='Guanambi',estado='BA',email_publico='teste@example.com')
    def test_cadastro_e_rotas(self):
        ExperienciaProfissional.objects.create(perfil=self.perfil,empresa='Empresa',cargo='Dev',descricao='Trabalho',inicio=date(2024,1,1),emprego_atual=True)
        FormacaoAcademica.objects.create(perfil=self.perfil,instituicao='Escola',curso='Informática',nivel='Técnico',inicio=date(2023,1,1),situacao='CURSANDO')
        Certificacao.objects.create(perfil=self.perfil,nome='Curso Python',emissor='Instituição',data_emissao=date(2025,1,1))
        for path in ('/api/experiencias/','/api/formacoes/','/api/certificacoes/'):
            self.assertEqual(len(self.client.get(path).json()['results']),1)
    def test_data_invalida(self):
        with self.assertRaises(ValidationError):
            ExperienciaProfissional.objects.create(perfil=self.perfil,empresa='E',cargo='Dev',descricao='T',inicio=date(2025,1,1),termino=date(2024,1,1))
