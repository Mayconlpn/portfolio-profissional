from django.apps import AppConfig
class ExperienciasConfig(AppConfig):
    default_auto_field='django.db.models.BigAutoField'
    name='experiencias'
    verbose_name='Experiências'
