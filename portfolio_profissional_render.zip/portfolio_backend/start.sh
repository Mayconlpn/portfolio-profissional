#!/usr/bin/env bash
set -euo pipefail

# O plano gratuito não oferece pre-deploy commands; migre antes de abrir a porta.
python manage.py migrate --noinput
python manage.py bootstrap_admin
exec gunicorn config.wsgi:application \
    --bind "0.0.0.0:${PORT:-10000}" \
    --workers 1 --threads 4 --timeout 60 \
    --access-logfile - --error-logfile -
